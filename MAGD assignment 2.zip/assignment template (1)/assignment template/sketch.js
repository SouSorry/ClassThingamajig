function setup() {
    createCanvas(400, 400);
}

function draw() {
    background(0);
    colorMode(RGB, 250, 250, 250, 1);
    noStroke();
    fill(250, 250, 250);
    ellipse(48, 56, 20, 20);
    offset = 80;

    beginShape();
    curveVertex(10, 50);
    curveVertex(40, 50);
    curveVertex(30, 20);
    curveVertex(30, 20);
    curveVertex(50, 50);
    curveVertex(50, 50);
    endShape();




    fill(100, 250, 100);

    ellipse(50, 200, 90, 90);

    fill(250, 250, 250, 0.75);
    beginShape();
    curveVertex(70, 79 + offset);
    curveVertex(70, 94 + offset);
    curveVertex(23, 104 + offset);
    curveVertex(15, 97 + offset);
    curveVertex(30, 100 + offset);
    curveVertex(30, 100 + offset);
    endShape();

    fill(50, 0, 100);

    ellipse(100, 105, 30, 15);



    fill(250, 250, 250, 1);

    arc(100, 100, 20, 20, 3.1, 6.3);

    ellipse(120, 20, 4);

    ellipse(135, 25, 2);

    ellipse(160, 18, 6);

    ellipse(163, 24, 3);

    ellipse(190, 25, 6);

    ellipse(200, 19, 2);

    ellipse(235, 24, 5);

    ellipse(305, 25, 6);

    ellipse(275, 23, 4);

    ellipse(340, 21, 3);

    ellipse(360, 25, 2);

    fill(20, 100, 100);

    ellipse(220, 200, 200, 200);

    fill(10, 10, 10, 0.25);

    ellipse(190, 200, 50);





    arc(270, 200, 20, 70, 0, 2);

    triangle(185, 190, 180, 200, 170, 200)

}