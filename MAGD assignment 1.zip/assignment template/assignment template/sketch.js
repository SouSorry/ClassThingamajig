function setup() {
    createCanvas(300, 400);
    background(200);


    noStroke();
    fill(51);

    rect(0, 0, 300, 200);

    fill(245);

    ellipse(50, 50, 30, 30);

    fill(75);

    ellipse(55, 45, 10, 10);
    ellipse(52, 50, 6, 6);


    stroke(0);
    fill(0);


    rect(0, 310, 50, 90);

    rect(60, 330, 50, 70);

    rect(130, 250, 50, 150);

    rect(135, 240, 40, 10);

    rect(145, 180, 5, 60);

    rect(160, 210, 5, 30);

    rect(200, 360, 80, 40);


    fill(200)
    rect(5, 320, 40, 10);
    rect(5, 340, 40, 10);
    rect(5, 360, 40, 10);

    rect(65, 340, 15, 10);
    rect(90, 340, 15, 10);

    rect(65, 360, 15, 10);
    rect(90, 360, 15, 10);
    rect(65, 380, 15, 10);
    rect(90, 380, 15, 10);

    rect(205, 370, 70, 10)
    rect(225, 370, 30, 10)


    noFill();
    strokeWeight(1.0);
    stroke(205);
    strokeJoin(MITER);
    beginShape();
    vertex(95, 60);
    vertex(130, 55);
    vertex(180, 55);
    vertex(155, 90);
    vertex(130, 55);
    vertex(180, 55);
    vertex(230, 35);
    vertex(205, 85);
    vertex(180, 55);
    endShape();

    noStroke();
    fill(255);
    ellipse(95, 60, 4, 4);
    ellipse(130, 55, 4, 4);
    ellipse(180, 55, 4, 4);
    ellipse(155, 90, 4, 4);
    ellipse(230, 35, 4, 4);
    ellipse(205, 85, 4, 4);

}


function draw() {

}