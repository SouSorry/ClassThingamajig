function setup() {
    createCanvas(400, 400);
    frameRate(30);
}

function draw() {
    background(220);
    colorMode(RGB, 250, 250, 250, 1);

    let x1 = 50;
    let y1 = 200;
    let x2 = mouseX;
    let y2 = mouseY;

    stroke(200, 1, 10)
    fill(125, 1, 10)
    rect(x1, y1, 20, 20)

    let d = dist(x1, y1, x2, y2)

    //ellipse(mouseX, mouseY, 9, 9);
    stroke(50, 130, 50);
    fill(50, 130, 50);
    line(x2, y2, pmouseX, pmouseY);

    ellipse(x2, y2, 5, 5);
    noStroke()
    fill(70, 20, 30)
    ellipse(200, 200, d, abs(d - 30))



}